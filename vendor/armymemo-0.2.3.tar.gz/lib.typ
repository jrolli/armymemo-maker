// armymemo — Typst package for AR 25-50 Army memorandums.
//
// Import `memo` and apply it to the memo body:
//
//   #import "@preview/armymemo:0.2.3": memo
//   #show: memo.with(office-symbol: "ATZB-CD-E", subject: "...", ...)
//   + First paragraph...
//
// `memo` sets the page, letterhead, routing, subject, and closing blocks, and
// numbers the body's `+` paragraphs in AR 25-50 style. `typst` is the only tool
// required. All measurements are derived from AR 25-50 (Preparing and Managing
// Correspondence, 10 October 2020, administrative revision 4 October 2024) and
// its memorandum figures.

// Fillable-field helpers from the vendored eform typst package (emitted as
// <eform-field> metadata consumed by `eform add-fields`). Re-exported for memo
// bodies that add their own fields.
#import "vendor/eform/lib.typ": field, text-field, checkbox, signature-field

#let layout = (
  page: (left: 72pt, right: 72pt, top: 132pt, bottom: 52pt),
  // Overridable at compile time, e.g. for hosts without Arial:
  //   typst compile --input font="Liberation Sans" memo.typ
  font-family: sys.inputs.at("font", default: "Arial"),
  font-size: 12pt,
  leading: 4pt,
  letterhead: (
    seal-dx: 33pt,
    seal-dy: 33pt,
    seal-height: 72pt,
    header-dx: 4pt,
    header-top: 36pt,
    dept-size: 10pt,
    detail-size: 8pt,
    line-gap: 2pt,
    suspense-dx: 72pt,
    suspense-dy: 104pt,
  ),
  heading: (
    gap-after-office: 18pt,
    gap-after-route: 36pt,
  ),
  continuation: (
    office-top: 72pt,
    subject-top: 88pt,
  ),
  route: (
    wrap-spacing: 6pt,
    hanging-indent: 18pt,
    paragraph-gap: 0pt,
    stacked-gap: -12pt,
  ),
  body: (
    paragraph-gap: 18pt,
    label-gap: 0.4em,
  ),
  // line-gap continues a list on the next line (single spacing, matching the
  // body's leading); authority-gap, distribution-gap, and cf-gap start their
  // lines "on the second line below" whatever precedes them (one blank line,
  // matching the body's paragraph spacing) per AR 25-50 paras 2-4c(1),
  // 2-4a(5)(c), and 2-4c(5).
  closing: (
    authority-gap: 18pt,
    sig-gap-no-authority: 58pt,
    sig-gap-authority: 66pt,
    line-gap: 4pt,
    distribution-gap: 18pt,
    dist-indent: 18pt,
    cf-gap: 18pt,
  ),
  // Boxes emitted as <eform-field> metadata for PDF signature form fields.
  // The concur box sits centered in the right margin, vertically centered on
  // its THRU addressee line(s). Stacked THRU lines are single-spaced with a
  // ~14.6pt pitch (paragraph spacing plus the stacked-gap), so the uniform
  // 14pt height keeps consecutive boxes clear of each other.
  eform: (
    signature-width: 2in,
    concur-width: 0.75in,
    concur-height: 14pt,
  ),
)

// AR 25-50 paragraph numbering label: 1. / a. / (1) / (a), keyed on nesting depth.
#let _para-depth = state("armymemo-para-depth", 0)
#let _army-label(depth, n) = {
  if depth == 1 {
    numbering("1.", n)
  } else if depth == 2 {
    numbering("a.", n)
  } else if depth == 3 {
    "(" + numbering("1", n) + ")"
  } else {
    "(" + numbering("a", n) + ")"
  }
}

// Join the present parts of a recipient (name, street, city/state/ZIP).
#let _recipient-line(recipient) = {
  let parts = (recipient.name,)
  let street = recipient.at("street", default: none)
  if street != none { parts.push(street) }
  let city = recipient.at("city-state-zip", default: none)
  if city != none { parts.push(city) }
  parts.join([, ])
}

// First-page letterhead and any suspense suspense date, drawn in the page
// foreground so the body always starts at the configured top margin.
// Bundled letterhead seals, keyed by the `seal` argument of `memo`.
#let _seal-files = (
  DOD: "DOD_Seal_BW.png",
  DOW: "DOW_Seal_BW.png",
)

#let _letterhead(organization, suspense, seal) = {
  let lh = layout.letterhead
  let header-top = lh.header-top
  let detail-top = header-top + lh.dept-size + lh.line-gap
  let detail-step = lh.detail-size + lh.line-gap

  place(top + left, dx: lh.seal-dx, dy: lh.seal-dy, image(_seal-files.at(seal), height: lh.seal-height))
  place(
    top + center,
    dx: lh.header-dx,
    dy: header-top,
    text(size: lh.dept-size, weight: "bold")[DEPARTMENT OF THE ARMY],
  )
  place(
    top + center,
    dx: lh.header-dx,
    dy: detail-top,
    text(size: lh.detail-size, weight: "bold")[#organization.name],
  )
  place(
    top + center,
    dx: lh.header-dx,
    dy: detail-top + detail-step,
    text(size: lh.detail-size, weight: "bold")[#organization.street],
  )
  place(
    top + center,
    dx: lh.header-dx,
    dy: detail-top + detail-step * 2,
    text(size: lh.detail-size, weight: "bold")[#organization.city-state-zip],
  )
  if suspense != none {
    place(
      top + right,
      dx: -lh.suspense-dx,
      dy: lh.suspense-dy,
      text(weight: "bold")[S: #suspense],
    )
  }
}

// Continuation pages (page 2+) repeat the office symbol and subject.
#let _continuation-header(office-symbol, subject) = {
  let cont = layout.continuation
  // The page foreground is anchored to the paper corner, so shift content in to
  // the left margin and constrain its width to the printable area.
  let margin = layout.page.left
  let printable = 100% - layout.page.left - layout.page.right
  place(top + left, dx: margin, dy: cont.office-top, block(width: printable)[#office-symbol])
  place(top + left, dx: margin, dy: cont.subject-top, block(width: printable)[SUBJECT: #subject])
}

// Office-symbol line with the date flush to the right margin.
#let _opening-block(office-symbol, date) = {
  block(width: 100%)[
    #office-symbol
    #h(1fr)
    #if date != none { date }
  ]
  v(layout.heading.gap-after-office)
}

// A single routing line with an AR-style 0.25" hanging indent for wraps.
#let _route-line(body, gap) = {
  par(hanging-indent: layout.route.hanging-indent)[#body]
  v(gap)
}

// Concurrence box for THRU addressee line `n`, whose full text is `body`.
// The box sits centered in the right margin and vertically centered on the
// line's extent — measured, so wrapped addressee lines center across all
// their lines. `field` is called INLINE, immediately before the anchor
// text, so the emitted box's (x, y) is the current layout position shifted by
// (dx, dy). Inside a real
// paragraph (which route lines are, for their hanging indent) an inline tag's
// position is the line's baseline, one cap height below the visual top-left
// that eform boxes are specified against — so shift dy up by the current
// font's measured cap height before centering.
#let _concur-field(n, body) = context {
  let ef = layout.eform
  let cap-height = measure(text[X]).height
  let printable = page.width - layout.page.left - layout.page.right
  let line-height = measure(
    width: printable,
    par(hanging-indent: layout.route.hanging-indent)[#body],
  ).height
  field(
    "Concur" + str(n),
    ef.concur-width,
    ef.concur-height,
    dx: printable + (layout.page.right - ef.concur-width) / 2,
    dy: -cap-height + (line-height - ef.concur-height) / 2,
  )
}

// MEMORANDUM FOR / THRU / FOR RECORD routing block. Every THRU addressee line
// carries an eform concurrence field (Concur1, Concur2, ...).
#let _route-block(memo-for, memo-thru) = {
  let rt = layout.route

  if memo-thru.len() == 0 and memo-for.len() == 0 {
    _route-line([MEMORANDUM FOR RECORD], rt.paragraph-gap)
    return
  }

  if memo-thru.len() == 1 {
    let body = [MEMORANDUM THRU #_recipient-line(memo-thru.at(0))]
    _route-line([#_concur-field(1, body)#body], rt.paragraph-gap)
  } else if memo-thru.len() > 1 {
    _route-line([MEMORANDUM THRU], rt.paragraph-gap)
    for (index, recipient) in memo-thru.enumerate() {
      let last = index == memo-thru.len() - 1
      let gap = if last and memo-for.len() > 0 { rt.paragraph-gap } else { rt.stacked-gap }
      let body = [#_recipient-line(recipient)]
      _route-line([#_concur-field(index + 1, body)#body], gap)
    }
  }

  if memo-for.len() == 1 {
    let prefix = if memo-thru.len() > 0 { [FOR ] } else { [MEMORANDUM FOR ] }
    _route-line([#prefix#_recipient-line(memo-for.at(0))], rt.paragraph-gap)
  } else if memo-for.len() > 1 {
    let label = if memo-thru.len() > 0 { [FOR] } else { [MEMORANDUM FOR] }
    _route-line(label, rt.paragraph-gap)
    for (index, recipient) in memo-for.enumerate() {
      let last = index == memo-for.len() - 1
      let gap = if last { rt.paragraph-gap } else { rt.stacked-gap }
      _route-line([#_recipient-line(recipient)], gap)
    }
  }
}

// Left-margin list (CF and friends) with a heading line. Explicit above
// spacing keeps the entries single-spaced; automatic block spacing would
// insert paragraph gaps between them.
#let _trailing-list(title, entries, top-gap) = {
  if entries.len() == 0 { return }
  block(width: 100%, above: top-gap, below: 0pt)[#title]
  for entry in entries {
    block(width: 100%, above: layout.closing.line-gap, below: 0pt)[#entry]
  }
}

// DISTRIBUTION listing (AR 25-50 para 2-4a(5)(c), figs 2-8 through 2-10).
// Entries may nest: an array element indents its entries 1/4 inch under the
// preceding entry, one level per nesting depth (fig 2-8's command groups).
#let _flatten-distribution(entries, depth: 0) = {
  let out = ()
  for entry in entries {
    if type(entry) == array {
      out += _flatten-distribution(entry, depth: depth + 1)
    } else {
      out.push((depth: depth, body: entry))
    }
  }
  out
}

// Every piece of the listing carries explicit above/below spacing: the
// pagination math below must know the exact flow advance of each block, and
// Typst's automatic (paragraph-spacing) block gaps would overrule the
// intended single-spaced line gap.
#let _dist-entry(item) = block(
  width: 100%,
  above: layout.closing.line-gap,
  below: 0pt,
  inset: (left: item.depth * layout.closing.dist-indent),
)[#item.body]

// First-page stub for a listing prepared on its own page (fig 2-9): the words
// "(see next page)" directly under "DISTRIBUTION:" on the next line.
#let _distribution-note() = {
  let cl = layout.closing
  block(width: 100%, above: cl.distribution-gap, below: 0pt)[DISTRIBUTION:]
  block(width: 100%, above: cl.line-gap, below: 0pt)[(see next page)]
}

// The DISTRIBUTION listing itself. AR 25-50 fig 2-8: a listing that overruns
// the page ends with "(CONT)" below its last entry and resumes under a
// "DISTRIBUTION: (CONT)" heading on the next page. Typst offers no hook at
// page breaks, so the listing is paginated by hand: anchor on the heading's
// final position, measure every entry, plan how many fit per page, and emit
// explicit page breaks with the continuation markers. `start-fresh` starts
// the listing at the top of its own page (the caller emits the preceding
// pagebreak; fig 2-9).
#let _distribution-list(entries, start-fresh) = {
  let cl = layout.closing
  let items = _flatten-distribution(entries)
  block(
    width: 100%,
    above: if start-fresh { 0pt } else { cl.distribution-gap },
    below: 0pt,
  )[DISTRIBUTION:]
  context {
    // Anchor below the heading, wherever it actually landed.
    let anchor-y = here().position().y
    let printable = page.width - layout.page.left - layout.page.right
    let content-height = page.height - layout.page.top - layout.page.bottom
    let head-cont = block(width: 100%, above: 0pt, below: 0pt)[DISTRIBUTION: (CONT)]
    let cont = block(width: 100%, above: cl.line-gap, below: 0pt)[(CONT)]
    let mh(body) = measure(width: printable, body).height
    let head-h = mh(head-cont)
    let cont-h = mh(cont)
    let heights = items.map(item => mh(_dist-entry(item)))
    // Measured heights match the emitted blocks exactly; the epsilon only
    // absorbs floating-point error so a chunk sized to the page never spills
    // a line past the planned break.
    let eps = 0.5pt

    // Plan the number of entries per page. Each entry advances the flow by
    // line-gap + its height; continuation pages open with their own heading.
    let plan = ()
    let idx = 0
    while idx < items.len() {
      let cap = if plan.len() == 0 {
        page.height - layout.page.bottom - anchor-y - eps
      } else {
        content-height - head-h - eps
      }
      let rest = heights.slice(idx).fold(0pt, (sum, h) => sum + cl.line-gap + h)
      let take = 0
      if rest <= cap {
        take = items.len() - idx
      } else {
        // This page also carries the trailing "(CONT)" line.
        let limit = cap - cl.line-gap - cont-h
        let used = 0pt
        while (
          idx + take < items.len() and used + cl.line-gap + heights.at(idx + take) <= limit
        ) {
          used += cl.line-gap + heights.at(idx + take)
          take += 1
        }
      }
      if take == 0 and plan.len() > 0 {
        // An entry taller than a full page: emit it anyway and let it break.
        take = 1
      }
      // take == 0 under a heading crowded against the page bottom is fine:
      // the "(CONT)" marker follows it and the listing resumes on the next
      // page.
      plan.push(take)
      idx += take
    }

    let idx = 0
    for (page-index, take) in plan.enumerate() {
      if page-index > 0 {
        pagebreak()
        head-cont
      }
      for i in range(idx, idx + take) {
        _dist-entry(items.at(i))
      }
      idx += take
      if idx < items.len() {
        cont
      }
    }
  }
}

// Authority line, signature block, and enclosure listing. The distribution
// and CF listings follow in the flow (emitted by `memo`) so a long
// distribution list can break across pages, which the AR provides for.
// `thru-count` is the number of MEMORANDUM THRU addressees, whose ConcurN
// fields must stay signable after the author signs.
#let _closing-block(author, authority, enclosures, thru-count) = {
  let cl = layout.closing

  // Enclosure listing (AR 25-50 para 4-2c). An array lists enclosures not
  // identified in the body: "Encl" plus the lone entry, or "N Encls" plus a
  // numbered list. An integer counts enclosures that are all identified in
  // the body, which the AR accounts for with the bare word (table 4-4):
  // "Encl" for one, "Encls" for more.
  let encl-count = if type(enclosures) == int { enclosures } else { enclosures.len() }
  assert(encl-count >= 0, message: "enclosures must be a count >= 0 or an array of entries")
  let encl-label = if type(enclosures) == int {
    if enclosures == 1 [Encl] else if enclosures > 1 [Encls] else { none }
  } else if enclosures.len() == 1 {
    [Encl]
  } else if enclosures.len() > 1 {
    [#enclosures.len() Encls]
  } else {
    none
  }
  // Runover lines of a listed enclosure align under the start of its text,
  // past the number (fig 2-2), so each numbered entry hangs by its own
  // measured label width.
  let encl-entries = if type(enclosures) == int or enclosures.len() <= 1 {
    if type(enclosures) == int { () } else { enclosures }
  } else {
    enclosures.enumerate().map(((index, value)) => {
      let label = [#(index + 1). ]
      context par(hanging-indent: measure(label).width)[#label#value]
    })
  }

  // The pen-signature space is the template's own gap above the typed name;
  // the eform box covers exactly that space, its bottom edge resting on the
  // top of the typed name's capitals.
  let sig-space = if authority != none { cl.sig-gap-authority } else { cl.sig-gap-no-authority } -0.25in
  // Signing the author's Signature field locks the form, except the ConcurN
  // fields the THRU addressees sign afterward.
  let lock = if thru-count == 0 {
    "all"
  } else {
    (action: "exclude", fields: range(thru-count).map(n => "Concur" + str(n + 1)))
  }
  let signature = {
    field(
      "Signature",
      layout.eform.signature-width,
      sig-space,
      dy: -sig-space - 0.125in,
      options: (lock: lock),
    )
    upper(author.name)
    linebreak()
    [#author.rank, #author.branch]
    if author.at("title", default: none) != none {
      linebreak()
      author.title
    }
  }

  // Signature block paired with the enclosure listing.
  let signature-and-trailing = table(
    columns: (1fr, 1fr),
    stroke: none,
    inset: 0pt,
    column-gutter: 0pt,
    [
      #if encl-label != none {
        block(width: 100%, above: 0pt, below: 0pt)[#encl-label]
        for entry in encl-entries {
          block(width: 100%, above: cl.line-gap, below: 0pt)[#entry]
        }
      }
    ],
    [#align(left)[#signature]],
  )

  // AR 25-50: the authority line sits two lines below the body; the signature
  // block begins on the fifth line below the authority line (or below the body
  // when there is no authority line). The closing stays on one page, and the
  // weak leading gap collapses with the body's trailing spacing so the offset
  // is deterministic regardless of body length.
  if authority != none {
    v(cl.authority-gap, weak: true)
    block(breakable: false)[
      #block(width: 100%)[#upper(authority):]
      #v(cl.sig-gap-authority)
      #signature-and-trailing
    ]
  } else {
    v(cl.sig-gap-no-authority, weak: true)
    block(breakable: false)[#signature-and-trailing]
  }
}

// Entry point. Apply it to a memo body with `#show: memo.with(..)`.
#let memo(
  office-symbol: "",
  date: none,
  subject: "",
  suspense: none,
  organization: (name: "", street: "", city-state-zip: ""),
  author: (name: "", rank: "", branch: ""),
  memo-for: (),
  memo-thru: (),
  authority: none,
  enclosures: (),
  distribution: (),
  see-distribution: false,
  distribution-separate-page: false,
  cf: (),
  cf-without-encls: false,
  seal: "DOD",
  doc,
) = {
  assert(
    seal in _seal-files,
    message: "seal must be one of " + _seal-files.keys().map(repr).join(", "),
  )
  // AR 25-50 para 2-4a(5)(c): a memorandum for more than five addressees uses
  // the SEE DISTRIBUTION format, with the addressees in the DISTRIBUTION
  // listing instead of the MEMORANDUM FOR line.
  assert(
    see-distribution or memo-for.len() <= 5,
    message: "AR 25-50 para 2-4a(5)(c): more than five addressees requires SEE"
      + " DISTRIBUTION — set see-distribution: true and list the addressees"
      + " under distribution",
  )
  assert(
    not see-distribution or memo-for.len() == 0,
    message: "see-distribution replaces memo-for; list the addressees under distribution",
  )
  assert(
    not see-distribution or distribution.len() > 0,
    message: "see-distribution requires a distribution list",
  )
  assert(
    not distribution-separate-page or distribution.len() > 0,
    message: "distribution-separate-page requires a distribution list",
  )
  set page(
    paper: "us-letter",
    margin: layout.page,
    header-ascent: 0pt,
    footer-descent: 0pt,
    foreground: context {
      if counter(page).get().first() == 1 {
        _letterhead(organization, suspense, seal)
      } else {
        _continuation-header(office-symbol, subject)
      }
    },
    footer: context {
      if counter(page).get().first() > 1 {
        align(center)[#counter(page).display()]
      }
    },
  )
  set text(font: layout.font-family, size: layout.font-size)
  set par(justify: false, leading: layout.leading, spacing: layout.body.paragraph-gap)

  // Memorandums are plain text; render inline code as ordinary body text.
  show raw: it => text(font: layout.font-family, size: layout.font-size)[#it.text]

  // AR 25-50 numbered paragraphs. Only the FIRST line of a (sub)paragraph is
  // indented to carry its number/letter; every runover line returns all the way
  // to the left margin, regardless of nesting depth. The first-line indent grows
  // one quarter inch per level, and the depth state selects the correct
  // 1. / a. / (1) / (a) label.
  show enum: it => {
    _para-depth.update(d => d + 1)
    context {
      let d = _para-depth.get()
      // AR 25-50: a subparagraph's number is aligned with the start of the
      // first-line text of its parent. The indent of a level is therefore the
      // cumulative width of the ancestor labels plus the number-to-text gap,
      // measured in the body font. The fourth level ((a)) shares the third
      // level's ((1)) indentation rather than indenting again.
      let gap = layout.body.label-gap
      let advance(label) = measure(label).width + measure(box(width: gap)).width
      let level = calc.min(d, 3)
      let indent = if level <= 1 {
        0pt
      } else if level == 2 {
        advance[1.]
      } else {
        advance[1.] + advance[a.]
      }
      // AR 25-50 para 2-4b(4)(a) and fig 2-13: a one-paragraph memorandum is
      // not numbered. A lone top-level item renders without its "1." label;
      // any subparagraphs keep their usual a. / (1) / (a) hierarchy.
      let one-paragraph = d == 1 and it.children.len() == 1
      for (i, child) in it.children.enumerate() {
        block(
          width: 100%,
          above: if d == 1 and i == 0 { 0pt } else { layout.body.paragraph-gap },
          below: 0pt,
          // AR 25-50 para 2-5c(4): the authority line and signature block may
          // not sit on a continuation page unless at least two lines of the
          // last paragraph (or the whole paragraph, when it has only one line)
          // come along. Sticking the last top-level paragraph to whatever
          // follows it (normally the closing) forbids a page break in between,
          // so the paragraph's tail — never fewer than two lines, thanks to
          // widow/orphan control — always accompanies the signature block.
          sticky: d == 1 and i == it.children.len() - 1,
        )[
          #set par(hanging-indent: 0pt, first-line-indent: 0pt)
          #if one-paragraph [#child.body] else [#box(width: indent)#_army-label(d, i + 1)#h(gap)#child.body]
        ]
      }
    }
    _para-depth.update(d => d - 1)
  }

  _opening-block(office-symbol, date)
  // SEE DISTRIBUTION replaces the addressees on the MEMORANDUM FOR line
  // (fig 2-8); the addressees move to the DISTRIBUTION listing.
  let route-for = if see-distribution { ((name: "SEE DISTRIBUTION"),) } else { memo-for }
  _route-block(route-for, memo-thru)
  block(width: 100%)[SUBJECT: #subject]
  v(layout.heading.gap-after-route)

  doc

  _closing-block(author, authority, enclosures, memo-thru.len())

  // AR 25-50 para 2-4c(5): "(w/o encls)" follows CF: when none of the CF
  // addressees receive copies of the enclosures.
  let cf-title = if cf-without-encls { [CF: (w/o encls)] } else { [CF:] }
  if distribution-separate-page and distribution.len() > 0 {
    // Fig 2-9: the first page carries only "DISTRIBUTION: (see next page)";
    // the listing occupies its own continuation page, so CF stays on the
    // first page below the stub.
    _distribution-note()
    _trailing-list(cf-title, cf, layout.closing.cf-gap)
    pagebreak()
    _distribution-list(distribution, true)
  } else {
    if distribution.len() > 0 {
      _distribution-list(distribution, false)
    }
    _trailing-list(cf-title, cf, layout.closing.cf-gap)
  }
}
